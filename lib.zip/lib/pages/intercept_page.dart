import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/api.dart';
import '../services/i18n.dart';
import '../widgets/ui.dart';

class InterceptPage extends StatefulWidget {
  const InterceptPage({super.key});
  @override
  State<InterceptPage> createState() => _InterceptPageState();
}

class _InterceptPageState extends State<InterceptPage> {
  final _editC = TextEditingController();
  int? _editingId;

  void _loadInto(Map<String, dynamic> req) {
    _editingId = req['id'] as int;
    final b = StringBuffer();
    b.writeln('${req['method']} ${req['path']} HTTP/1.1');
    (req['headers'] as Map).forEach((k, v) => b.writeln('$k: $v'));
    b.writeln();
    b.write(req['body'] ?? '');
    _editC.text = b.toString();
  }

  (String, String, Map<String, String>, String) _parse(String text) {
    final lines = text.split('\n');
    String method = 'GET', path = '/';
    if (lines.isNotEmpty) {
      final parts = lines[0].trim().split(' ');
      if (parts.length >= 2) {
        method = parts[0];
        path = parts[1];
      }
    }
    final headers = <String, String>{};
    int i = 1;
    for (; i < lines.length; i++) {
      final line = lines[i].trimRight();
      if (line.isEmpty) {
        i++;
        break;
      }
      final idx = line.indexOf(':');
      if (idx > 0) headers[line.substring(0, idx).trim()] = line.substring(idx + 1).trim();
    }
    final body = i < lines.length ? lines.sublist(i).join('\n') : '';
    return (method, path, headers, body);
  }

  Future<void> _forward(int id, {bool modified = false}) async {
    Map<String, dynamic>? mod;
    if (modified) {
      final (m, p, h, b) = _parse(_editC.text);
      mod = {'method': m, 'path': p, 'headers': h, 'body': b};
    }
    await Api.instance.resolveIntercept(id, 'forward', modified: mod);
    if (_editingId == id) {
      _editingId = null;
      _editC.clear();
    }
    setState(() {});
  }

  Future<void> _drop(int id) async {
    await Api.instance.resolveIntercept(id, 'drop');
    if (_editingId == id) {
      _editingId = null;
      _editC.clear();
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Api.instance,
      builder: (context, _) {
        final api = Api.instance;
        final pending = api.pendingIntercept;
        if (_editingId != null && !pending.any((e) => e['id'] == _editingId)) {
          _editingId = null;
        }
        if (_editingId == null && pending.isNotEmpty) {
          _loadInto(pending.first);
        }
        return PageBody(
          scroll: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PageHeader(
                crumbs: [tr('Lalu lintas', 'Traffic'), 'Intercept'],
                title: 'Intercept',
                subtitle: tr('Request yang tertahan menunggu keputusanmu. Aktifkan mode intercept di halaman Proxy.',
                    'Held requests waiting for your decision. Enable intercept mode on the Proxy page.'),
                actions: [
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Text('Intercept', style: YmTextStyles.labelMd),
                    const SizedBox(width: 8),
                    Switch(value: api.intercepting, onChanged: (v) => api.putConfig({'intercept': v})),
                  ]),
                ],
              ),
              const SizedBox(height: 16),
              if (pending.isEmpty)
                Expanded(
                  child: EmptyState(
                    icon: Icons.pan_tool_outlined,
                    title: api.intercepting ? tr('Tidak ada request tertahan', 'No held requests') : tr('Mode intercept mati', 'Intercept mode is off'),
                    message: api.intercepting
                        ? tr('Saat ada request masuk, ia akan muncul di sini untuk kamu teruskan / ubah / drop.', 'When a request comes in, it appears here to forward / edit / drop.')
                        : tr('Nyalakan mode intercept lalu buka aplikasimu.', 'Turn on intercept mode, then open your app.'),
                  ),
                )
              else
                Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(
                        width: 260,
                        child: Container(
                          decoration: BoxDecoration(color: YmColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: YmColors.line)),
                          clipBehavior: Clip.antiAlias,
                          child: ListView(
                            children: [
                              for (final req in pending)
                                InkWell(
                                  onTap: () => setState(() => _loadInto(req)),
                                  child: Container(
                                    color: req['id'] == _editingId ? YmColors.surfaceHigh : Colors.transparent,
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Row(children: [
                                        Text(req['method'] as String, style: YmTextStyles.labelSm.copyWith(color: methodColor(req['method'] as String), fontWeight: FontWeight.w700)),
                                        const SizedBox(width: 6),
                                        Expanded(child: Text(req['host'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: YmTextStyles.labelMd)),
                                      ]),
                                      const SizedBox(height: 2),
                                      Text(req['path'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: YmTextStyles.bodySm),
                                    ]),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(color: YmColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: YmColors.line)),
                                clipBehavior: Clip.antiAlias,
                                child: TextField(
                                  controller: _editC,
                                  expands: true,
                                  maxLines: null,
                                  textAlignVertical: TextAlignVertical.top,
                                  style: YmTextStyles.mono,
                                  decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.all(12)),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            if (_editingId != null)
                              Row(children: [
                                ElevatedButton.icon(onPressed: () => _forward(_editingId!, modified: true), icon: const Icon(Icons.edit_rounded, size: 18), label: Text(tr('Teruskan (dengan perubahan)', 'Forward (with changes)'))),
                                const SizedBox(width: 8),
                                OutlinedButton.icon(onPressed: () => _forward(_editingId!), icon: const Icon(Icons.fast_forward_rounded, size: 18), label: Text(tr('Teruskan apa adanya', 'Forward as-is'))),
                                const SizedBox(width: 8),
                                OutlinedButton.icon(
                                  onPressed: () => _drop(_editingId!),
                                  style: OutlinedButton.styleFrom(foregroundColor: YmColors.danger),
                                  icon: const Icon(Icons.block_rounded, size: 18),
                                  label: const Text('Drop'),
                                ),
                              ]),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
